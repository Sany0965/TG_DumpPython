import asyncio
import os
import shutil
import threading
import time
from pathlib import Path

_server = None
_thread = None
_port = 8080
_ready = threading.Event()
_error = None


def _run_server(data_dir):
    global _server, _error
    try:
        os.environ["TG_DUMP_DATA"] = str(data_dir)
        import web_app
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        app = web_app.make_app()
        runner = web_app.web.AppRunner(app)
        loop.run_until_complete(runner.setup())
        site = web_app.web.TCPSite(runner, "127.0.0.1", 8080)
        loop.run_until_complete(site.start())
        _server = (loop, runner)
        _ready.set()
        loop.run_forever()
    except Exception as error:
        _error = error
        _ready.set()


def start_server(data_dir):
    global _thread
    data = Path(data_dir)
    data.mkdir(parents=True, exist_ok=True)
    runtime = data / "runtime"
    runtime.mkdir(exist_ok=True)
    bundled = Path(__file__).resolve().parent / "config.json"
    if not bundled.exists():
        bundled = Path(__file__).resolve().parent / "config.example.json"
    target = data / "config.json"
    if not target.exists() and bundled.exists():
        shutil.copy2(bundled, target)
    if _thread is None or not _thread.is_alive():
        _ready.clear()
        _error = None
        _thread = threading.Thread(target=_run_server, args=(data,), daemon=True)
        _thread.start()
    if not _ready.wait(45):
        raise RuntimeError("Локальный сервер не запустился вовремя")
    if _error is not None:
        raise _error
    return 8080
