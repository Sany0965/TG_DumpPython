package ru.sany.tgdump;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class ExportCancelReceiver extends BroadcastReceiver {
    public static final String ACTION_CANCEL_EXPORT = "ru.sany.tgdump.CANCEL_EXPORT";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!ACTION_CANCEL_EXPORT.equals(intent.getAction())) return;
        new Thread(() -> {
            try {
                HttpURLConnection connection = (HttpURLConnection)
                        new URL("http://127.0.0.1:8080/api/cancel").openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(2500);
                connection.setReadTimeout(2500);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json");
                try (OutputStream output = connection.getOutputStream()) {
                    output.write("{}".getBytes(java.nio.charset.StandardCharsets.UTF_8));
                }
                connection.getResponseCode();
                connection.disconnect();
            } catch (Exception ignored) {
            }
        }).start();
    }
}
