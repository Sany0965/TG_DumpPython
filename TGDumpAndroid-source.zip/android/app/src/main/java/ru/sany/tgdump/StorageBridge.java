package ru.sany.tgdump;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public final class StorageBridge {
    private static Context context;
    private static final int EXPORT_NOTIFICATION_ID = 14001;
    private static final int COMPLETE_NOTIFICATION_ID = 14002;
    private static final String EXPORT_CHANNEL_ID = "tg_dump_exports";

    private StorageBridge() {}

    public static void init(Context value) {
        context = value.getApplicationContext();
    }

    public static boolean isNetworkAvailable() {
        if (context == null) return true;
        android.net.ConnectivityManager manager =
                (android.net.ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) return true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            android.net.Network network = manager.getActiveNetwork();
            if (network == null) return false;
            android.net.NetworkCapabilities capabilities = manager.getNetworkCapabilities(network);
            return capabilities != null && capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
        }
        android.net.NetworkInfo info = manager.getActiveNetworkInfo();
        return info == null || info.isConnected();
    }

    private static Notification.Builder notificationBuilder(String channelTitle) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    EXPORT_CHANNEL_ID, channelTitle, NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Прогресс экспорта TG Dump");
            manager.createNotificationChannel(channel);
            return new Notification.Builder(context, EXPORT_CHANNEL_ID);
        }
        return new Notification.Builder(context);
    }

    private static PendingIntent cancelPendingIntent() {
        Intent intent = new Intent(context, ExportCancelReceiver.class);
        intent.setAction(ExportCancelReceiver.ACTION_CANCEL_EXPORT);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, 14003, intent, flags);
    }

    public static void updateExportNotification(String title, int progress, boolean cancellable) {
        if (context == null) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        int value = Math.max(0, Math.min(100, progress));
        Notification.Builder builder = notificationBuilder("TG Dump");
        builder.setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("Экспорт: " + (title == null || title.isEmpty() ? "Telegram" : title))
                .setContentText("Выполнено: " + value + "%")
                .setOnlyAlertOnce(true)
                .setOngoing(cancellable)
                .setAutoCancel(!cancellable)
                .setProgress(100, value, false);
        if (cancellable) {
            builder.addAction(new Notification.Action.Builder(
                    Icon.createWithResource(context, android.R.drawable.ic_menu_close_clear_cancel),
                    "Отменить", cancelPendingIntent()).build());
        }
        manager.notify(EXPORT_NOTIFICATION_ID, builder.build());
    }

    public static void showExportComplete(String title) {
        if (context == null) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder builder = notificationBuilder("TG Dump");
        builder.setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Экспорт завершён")
                .setContentText(title == null || title.isEmpty() ? "Архив сохранён в Download/TG DUMP" : title)
                .setAutoCancel(true)
                .setOngoing(false);
        manager.cancel(EXPORT_NOTIFICATION_ID);
        manager.notify(COMPLETE_NOTIFICATION_ID, builder.build());
    }

    public static void showExportCancelled() {
        if (context == null) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.cancel(EXPORT_NOTIFICATION_ID);
        Notification.Builder builder = notificationBuilder("TG Dump");
        builder.setSmallIcon(android.R.drawable.ic_delete)
                .setContentTitle("Экспорт отменён")
                .setAutoCancel(true)
                .setOngoing(false);
        manager.notify(COMPLETE_NOTIFICATION_ID, builder.build());
    }

    public static void openDownloadFolder() {
        openDownloadFolder("");
    }

    public static void openDownloadFolder(String relativePath) {
        if (context == null) return;
        try {
            String clean = relativePath == null ? "" : relativePath.replace('\\', '/');
            int slash = clean.lastIndexOf('/');
            if (slash >= 0) clean = clean.substring(0, slash);
            String documentId = "primary:Download/TG DUMP" + (clean.isEmpty() ? "" : "/" + clean);
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Uri initial = DocumentsContract.buildTreeDocumentUri(
                        "com.android.externalstorage.documents", documentId);
                intent.putExtra("android.provider.extra.INITIAL_URI", initial);
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception ignored) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("content://com.android.externalstorage.documents/root/primary"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }
    }

    public static void deleteDownloadPath(String relativePath, boolean directory) throws IOException {
        String relative = relativePath == null ? "" : relativePath.replace('\\', '/');
        while (relative.startsWith("/")) relative = relative.substring(1);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (context == null) throw new IOException("Storage bridge is not initialized");
            ContentResolver resolver = context.getContentResolver();
            Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            String prefix = "Download/TG DUMP/" + relative;
            String[] projection = {MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.RELATIVE_PATH};
            try (Cursor cursor = resolver.query(collection, projection, null, null, null)) {
                if (cursor == null) return;
                int idIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
                int nameIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME);
                int pathIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH);
                while (cursor.moveToNext()) {
                    String display = cursor.getString(nameIndex);
                    String path = cursor.getString(pathIndex);
                    boolean match;
                    if (relative.isEmpty()) {
                        match = path.startsWith("Download/TG DUMP/");
                    } else if (directory) {
                        match = path.startsWith(prefix + "/");
                    } else {
                        match = path.equals("Download/TG DUMP/") && display.equals(relative);
                    }
                    if (match) {
                        Uri item = Uri.withAppendedPath(collection, cursor.getString(idIndex));
                        resolver.delete(item, null, null);
                    }
                }
            }
        } else {
            File target = new File(getDownloadFolder(), relative);
            deleteRecursive(target);
        }
    }

    private static void deleteRecursive(File file) {
        if (!file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursive(child);
        }
        file.delete();
    }

    public static String getDownloadFolder() {
        return new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "TG DUMP"
        ).getAbsolutePath();
    }

    public static String copyFileToDownloads(String sourcePath, String displayName) throws IOException {
        File source = new File(sourcePath);
        if (!source.isFile()) {
            throw new IOException("Source file does not exist: " + sourcePath);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            copyOneMediaStore(source, "TG DUMP", displayName);
        } else {
            File targetDir = new File(getDownloadFolder());
            if (!targetDir.exists() && !targetDir.mkdirs()) {
                throw new IOException("Cannot create " + targetDir);
            }
            copyStream(source, new File(targetDir, displayName));
        }
        return new File(getDownloadFolder(), displayName).getAbsolutePath();
    }

    public static String copyTreeToDownloads(String sourcePath, String folder) throws IOException {
        File source = new File(sourcePath);
        if (!source.exists()) {
            throw new IOException("Source does not exist: " + sourcePath);
        }
        String cleanFolder = normalizeFolder(folder);
        if (source.isFile()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                copyOneMediaStore(source, cleanFolder, source.getName());
            } else {
                File target = new File(getDownloadFolder(), cleanFolder.equals("TG DUMP") ? "" : cleanFolder.substring("TG DUMP/".length()));
                if (!target.exists() && !target.mkdirs()) throw new IOException("Cannot create " + target);
                copyStream(source, new File(target, source.getName()));
            }
            return new File(getDownloadFolder(), source.getName()).getAbsolutePath();
        }

        List<File> files = new ArrayList<>();
        collectFiles(source, files);
        for (File file : files) {
            String relative = source.toPath().relativize(file.toPath()).toString().replace(File.separatorChar, '/');
            String relativeFolder = cleanFolder;
            int slash = relative.lastIndexOf('/');
            String name = relative;
            if (slash >= 0) {
                relativeFolder += "/" + relative.substring(0, slash);
                name = relative.substring(slash + 1);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                copyOneMediaStore(file, relativeFolder, name);
            } else {
                File targetDir = new File(getDownloadFolder(), relativeFolder.equals("TG DUMP") ? "" : relativeFolder.substring("TG DUMP/".length()));
                if (!targetDir.exists() && !targetDir.mkdirs()) throw new IOException("Cannot create " + targetDir);
                copyStream(file, new File(targetDir, name));
            }
        }
        return new File(getDownloadFolder(), cleanFolder.equals("TG DUMP") ? "" : cleanFolder.substring("TG DUMP/".length())).getAbsolutePath();
    }

    private static String normalizeFolder(String folder) {
        String value = (folder == null ? "" : folder).replace('\\', '/');
        while (value.startsWith("/")) value = value.substring(1);
        if (!value.equals("TG DUMP") && !value.startsWith("TG DUMP/")) {
            value = "TG DUMP/" + value;
        }
        return value.replaceAll("/+", "/");
    }

    private static void collectFiles(File directory, List<File> result) {
        File[] children = directory.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.isDirectory()) collectFiles(child, result);
            else if (child.isFile()) result.add(child);
        }
    }

    private static void copyOneMediaStore(File source, String folder, String displayName) throws IOException {
        if (context == null) throw new IOException("Storage bridge is not initialized");
        ContentResolver resolver = context.getContentResolver();
        String relativePath = Environment.DIRECTORY_DOWNLOADS + "/" + normalizeFolder(folder) + "/";
        Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        deleteExisting(resolver, collection, displayName, relativePath);
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
        values.put(MediaStore.MediaColumns.MIME_TYPE, mimeFor(displayName));
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath);
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = resolver.insert(collection, values);
        if (uri == null) throw new IOException("Cannot create MediaStore item");
        try {
            try (InputStream input = new FileInputStream(source);
                 OutputStream output = resolver.openOutputStream(uri)) {
                if (output == null) throw new IOException("Cannot open MediaStore output");
                byte[] buffer = new byte[1024 * 1024];
                int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            }
            ContentValues ready = new ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
            resolver.update(uri, ready, null, null);
        } catch (Exception error) {
            resolver.delete(uri, null, null);
            if (error instanceof IOException) throw (IOException) error;
            throw new IOException(error);
        }
    }

    private static void deleteExisting(ContentResolver resolver, Uri collection, String name, String relativePath) {
        String[] projection = {MediaStore.MediaColumns._ID};
        String selection = MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?";
        String[] args = {name, relativePath};
        try (Cursor cursor = resolver.query(collection, projection, selection, args, null)) {
            if (cursor == null) return;
            int id = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
            while (cursor.moveToNext()) {
                Uri item = Uri.withAppendedPath(collection, cursor.getString(id));
                resolver.delete(item, null, null);
            }
        }
    }

    private static String mimeFor(String name) {
        String lower = name.toLowerCase();
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".txt")) return "text/plain";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".zip")) return "application/zip";
        if (lower.endsWith(".session")) return "application/octet-stream";
        return "application/octet-stream";
    }

    private static void copyStream(File source, File destination) throws IOException {
        File parent = destination.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Cannot create " + parent);
        try (InputStream input = new FileInputStream(source); OutputStream output = new FileOutputStream(destination)) {
            byte[] buffer = new byte[1024 * 1024];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
        }
    }
}
