plugins {
    id("com.android.application")
    id("com.chaquo.python")
}

android {
    namespace = "ru.sany.tgdump"
    compileSdk = 34

    defaultConfig {
        applicationId = "ru.sany.tgdump"
        minSdk = 24
        targetSdk = 34
        versionCode = 14000
        versionName = "14.0"
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

chaquopy {
    defaultConfig {
        version = "3.12"
        buildPython("/usr/bin/python3.12")
        pip {
            install("-r", "requirements-android.txt")
        }
    }
}
